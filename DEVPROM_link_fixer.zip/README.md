This is a Firefox plugin which fixes the DEVPROM links with spaces with well formatted URL.

[URL with spaces]

https://devprom.***.com/pm/Project/Group - 986045

with

[URL + Title]

https://devprom.***.com/pm/Project/Group%20-%20986045 text prompt sample

# References
1. https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Your_first_WebExtension
2. https://extensionworkshop.com/documentation/publish/submitting-an-add-on/
